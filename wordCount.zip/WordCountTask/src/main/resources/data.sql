insert into aliens values(552,'rohit');
insert into aliens values(540,'ganesh');
insert into aliens values(557,'gunndu');
insert into aliens values(535,'shivanand');
insert into aliens values(528,'amrthya');