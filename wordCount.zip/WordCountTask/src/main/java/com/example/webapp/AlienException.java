package com.example.webapp;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class AlienException {
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler({RuntimeException.class})
	public void handle() {}
	
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler({AlienNotFoundException.class})
	public void handle(AlienNotFoundException e) {
		
	}
}