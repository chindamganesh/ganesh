package com.example.webapp;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AlienRepository extends JpaRepository<Aliens, Integer> {

	@Query("from Aliens where id=?1 and password=?2")
	public List<Aliens> findByIdLoging(int id, String password);
}
