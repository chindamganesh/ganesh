package com.example.webapp;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class AlienNotFoundException extends RuntimeException
{
	public AlienNotFoundException(String message) {
		super(message);
	}
}
