package com.example.webapp;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AlieanResource {
	@Autowired
	AlienRepository repo;

	@PostMapping("loginPage")
	public ResponseEntity<String> login(@RequestBody Aliens alien, HttpSession session) {
		
		List<Aliens> matchedAlien ;
		try {
			matchedAlien = repo.findByIdLoging(alien.getId(), alien.getPassword());
			session.setAttribute("id", alien.getId());
			
			if(matchedAlien.isEmpty()) {
				System.out.println(matchedAlien);
				return new ResponseEntity<String>("success", HttpStatus.OK);
			}
			else
			{
				
				return new ResponseEntity<String>("fail", HttpStatus.OK);
			}
		}
		catch(RuntimeException e) {
		return new ResponseEntity<String>(null,null,HttpStatus.INTERNAL_SERVER_ERROR);
		
		}
		
		
	}
	
	@GetMapping("logout")
	public String logout(HttpSession session) {
		session.removeAttribute("id");
		
		return "login.jsp";
	}
	
	@PostMapping("getCount")
	public ResponseEntity<String> getCount(@RequestBody String testWord) throws Exception {
		
		File file = ResourceUtils.getFile("classpath:config/textfile.txt");
		testWord=testWord.substring(3, testWord.length()-4);
		testWord = testWord.toLowerCase();
		System.out.println(testWord);
		FileInputStream fin = new FileInputStream(file);
		Scanner fileInput = new Scanner(fin);
		
		//Creating Map Collection...
		Scanner scan = new Scanner(System.in);
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		
		//storing all words with Count in map..
		while(fileInput.hasNext()) 
		{
			String nextWord = fileInput.next().replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
			if(map.containsKey(nextWord)) {
				
				int count = map.get(nextWord)+1;
				map.put(nextWord, count);
			}
			else {
				map.put(nextWord, 1);
			}
		}
		fileInput.close();
		scan.close();
		String result= map.get(testWord)+"";
		if(map.containsKey(testWord)) {
			return new ResponseEntity<String>(result,HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("word does not exsist",HttpStatus.OK);
		}
			
	}
	
}
