package com.example.webapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AlienController {

	@RequestMapping("login")
	public String alien() {
		
		return "login.jsp";
	}
}
